package com.vidmate.app.model;

import java.util.List;

public class VideoResponse {
    private String kind;
    private String etag;
    private List<VideoItemDetail> items;

    public String getKind() { return kind; }
    public void setKind(String kind) { this.kind = kind; }

    public String getEtag() { return etag; }
    public void setEtag(String etag) { this.etag = etag; }

    public List<VideoItemDetail> getItems() { return items; }
    public void setItems(List<VideoItemDetail> items) { this.items = items; }

    public static class VideoItemDetail {
        private String kind;
        private String etag;
        private String id;
        private Snippet snippet;
        private ContentDetails contentDetails;
        private Statistics statistics;

        public String getKind() { return kind; }
        public void setKind(String kind) { this.kind = kind; }

        public String getEtag() { return etag; }
        public void setEtag(String etag) { this.etag = etag; }

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }

        public Snippet getSnippet() { return snippet; }
        public void setSnippet(Snippet snippet) { this.snippet = snippet; }

        public ContentDetails getContentDetails() { return contentDetails; }
        public void setContentDetails(ContentDetails contentDetails) { this.contentDetails = contentDetails; }

        public Statistics getStatistics() { return statistics; }
        public void setStatistics(Statistics statistics) { this.statistics = statistics; }
    }

    public static class Snippet {
        private String publishedAt;
        private String channelId;
        private String title;
        private String description;
        private SearchResponse.Thumbnails thumbnails;
        private String channelTitle;
        private List<String> tags;
        private String categoryId;
        private String liveBroadcastContent;
        private Localized localized;

        public String getPublishedAt() { return publishedAt; }
        public void setPublishedAt(String publishedAt) { this.publishedAt = publishedAt; }

        public String getChannelId() { return channelId; }
        public void setChannelId(String channelId) { this.channelId = channelId; }

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public SearchResponse.Thumbnails getThumbnails() { return thumbnails; }
        public void setThumbnails(SearchResponse.Thumbnails thumbnails) { this.thumbnails = thumbnails; }

        public String getChannelTitle() { return channelTitle; }
        public void setChannelTitle(String channelTitle) { this.channelTitle = channelTitle; }

        public List<String> getTags() { return tags; }
        public void setTags(List<String> tags) { this.tags = tags; }

        public String getCategoryId() { return categoryId; }
        public void setCategoryId(String categoryId) { this.categoryId = categoryId; }

        public String getLiveBroadcastContent() { return liveBroadcastContent; }
        public void setLiveBroadcastContent(String liveBroadcastContent) { this.liveBroadcastContent = liveBroadcastContent; }

        public Localized getLocalized() { return localized; }
        public void setLocalized(Localized localized) { this.localized = localized; }
    }

    public static class Localized {
        private String title;
        private String description;

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
    }

    public static class ContentDetails {
        private String duration;
        private String dimension;
        private String definition;
        private String caption;
        private String licensedContent;
        private String projection;

        public String getDuration() { return duration; }
        public void setDuration(String duration) { this.duration = duration; }

        public String getDimension() { return dimension; }
        public void setDimension(String dimension) { this.dimension = dimension; }

        public String getDefinition() { return definition; }
        public void setDefinition(String definition) { this.definition = definition; }

        public String getCaption() { return caption; }
        public void setCaption(String caption) { this.caption = caption; }

        public String getLicensedContent() { return licensedContent; }
        public void setLicensedContent(String licensedContent) { this.licensedContent = licensedContent; }

        public String getProjection() { return projection; }
        public void setProjection(String projection) { this.projection = projection; }
    }

    public static class Statistics {
        private long viewCount;
        private long likeCount;
        private long dislikeCount;
        private long favoriteCount;
        private long commentCount;

        public long getViewCount() { return viewCount; }
        public void setViewCount(long viewCount) { this.viewCount = viewCount; }

        public long getLikeCount() { return likeCount; }
        public void setLikeCount(long likeCount) { this.likeCount = likeCount; }

        public long getDislikeCount() { return dislikeCount; }
        public void setDislikeCount(long dislikeCount) { this.dislikeCount = dislikeCount; }

        public long getFavoriteCount() { return favoriteCount; }
        public void setFavoriteCount(long favoriteCount) { this.favoriteCount = favoriteCount; }

        public long getCommentCount() { return commentCount; }
        public void setCommentCount(long commentCount) { this.commentCount = commentCount; }
    }
}
