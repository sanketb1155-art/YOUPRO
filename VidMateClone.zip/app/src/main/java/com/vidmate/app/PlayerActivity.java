package com.vidmate.app;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.PlayerView;
import com.vidmate.app.model.VideoItem;
import com.vidmate.app.model.DownloadItem;
import com.vidmate.app.network.VideoExtractor;
import com.vidmate.app.utils.PreferenceManager;
import com.vidmate.app.utils.Utils;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlayerActivity extends AppCompatActivity {

    private PlayerView playerView;
    private ExoPlayer exoPlayer;
    private ImageView thumbnailImage;
    private TextView titleText;
    private TextView channelText;
    private TextView viewsText;
    private TextView descriptionText;
    private ImageButton downloadButton;
    private ImageButton shareButton;
    private ImageButton backButton;
    private ProgressBar progressBar;
    private LinearLayout infoContainer;

    private String videoId;
    private String videoTitle;
    private String videoThumb;
    private String channelName;
    private PreferenceManager prefs;
    private VideoExtractor extractor;
    private List<VideoExtractor.VideoStream> availableStreams;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        prefs = new PreferenceManager(this);
        extractor = new VideoExtractor();
        availableStreams = new ArrayList<VideoExtractor.VideoStream>();

        videoId = getIntent().getStringExtra(Constants.EXTRA_VIDEO_ID);
        videoTitle = getIntent().getStringExtra(Constants.EXTRA_VIDEO_TITLE);
        videoThumb = getIntent().getStringExtra(Constants.EXTRA_VIDEO_THUMB);
        channelName = getIntent().getStringExtra(Constants.EXTRA_CHANNEL_NAME);

        initViews();
        setupPlayer();
        loadVideoInfo();

        boolean showDownload = getIntent().getBooleanExtra("show_download", false);
        if (showDownload) {
            showDownloadDialog();
        }
    }

    private void initViews() {
        playerView = findViewById(R.id.playerView);
        thumbnailImage = findViewById(R.id.thumbnailImage);
        titleText = findViewById(R.id.titleText);
        channelText = findViewById(R.id.channelText);
        viewsText = findViewById(R.id.viewsText);
        descriptionText = findViewById(R.id.descriptionText);
        downloadButton = findViewById(R.id.downloadButton);
        shareButton = findViewById(R.id.shareButton);
        backButton = findViewById(R.id.backButton);
        progressBar = findViewById(R.id.progressBar);
        infoContainer = findViewById(R.id.infoContainer);

        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        downloadButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDownloadDialog();
            }
        });

        shareButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                shareVideo();
            }
        });
    }

    private void setupPlayer() {
        exoPlayer = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(exoPlayer);

        // Load thumbnail first
        Glide.with(this)
            .load(videoThumb)
            .placeholder(R.drawable.thumbnail_placeholder)
            .into(thumbnailImage);

        // Extract video streams and play
        progressBar.setVisibility(View.VISIBLE);
        extractor.extractVideo(videoId, new VideoExtractor.ExtractCallback() {
            public void onSuccess(List<VideoExtractor.VideoStream> streams) {
                availableStreams = streams;
                progressBar.setVisibility(View.GONE);

                if (streams.size() > 0) {
                    // Find best quality stream
                    VideoExtractor.VideoStream bestStream = findBestStream(streams);
                    if (bestStream != null) {
                        playVideo(bestStream.getUrl());
                    }
                }
            }

            public void onError(String error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(PlayerActivity.this, "Error loading video: " + error, Toast.LENGTH_LONG).show();
                // Show thumbnail as fallback
                thumbnailImage.setVisibility(View.VISIBLE);
            }
        });

        exoPlayer.addListener(new Player.Listener() {
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    thumbnailImage.setVisibility(View.GONE);
                }
            }

            public void onPlayerError(PlaybackException error) {
                Toast.makeText(PlayerActivity.this, "Playback error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private VideoExtractor.VideoStream findBestStream(List<VideoExtractor.VideoStream> streams) {
        VideoExtractor.VideoStream best = null;
        for (int i = 0; i < streams.size(); i++) {
            VideoExtractor.VideoStream stream = streams.get(i);
            if (stream.getType().equals("video") && !stream.getQuality().equals("Unknown")) {
                if (best == null || isBetterQuality(stream.getQuality(), best.getQuality())) {
                    best = stream;
                }
            }
        }
        return best != null ? best : (streams.size() > 0 ? streams.get(0) : null);
    }

    private boolean isBetterQuality(String newQuality, String currentQuality) {
        int newVal = parseQuality(newQuality);
        int curVal = parseQuality(currentQuality);
        return newVal > curVal;
    }

    private int parseQuality(String quality) {
        try {
            return Integer.parseInt(quality.replace("p", "").replace("k", "").trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private void playVideo(String videoUrl) {
        MediaItem mediaItem = MediaItem.fromUri(videoUrl);
        exoPlayer.setMediaItem(mediaItem);
        exoPlayer.prepare();
        exoPlayer.play();
    }

    private void loadVideoInfo() {
        titleText.setText(videoTitle != null ? videoTitle : "Unknown");
        channelText.setText(channelName != null ? channelName : "Unknown Channel");

        // You can fetch more details here if needed
    }

    private void showDownloadDialog() {
        if (availableStreams == null || availableStreams.size() == 0) {
            Toast.makeText(this, "Loading video info...", Toast.LENGTH_SHORT).show();

            progressBar.setVisibility(View.VISIBLE);
            extractor.extractVideo(videoId, new VideoExtractor.ExtractCallback() {
                public void onSuccess(List<VideoExtractor.VideoStream> streams) {
                    availableStreams = streams;
                    progressBar.setVisibility(View.GONE);
                    showDownloadOptionsDialog();
                }

                public void onError(String error) {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(PlayerActivity.this, "Failed to get download links", Toast.LENGTH_SHORT).show();
                }
            });
            return;
        }

        showDownloadOptionsDialog();
    }

    private void showDownloadOptionsDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_download);

        RadioGroup qualityGroup = dialog.findViewById(R.id.qualityGroup);
        RadioGroup formatGroup = dialog.findViewById(R.id.formatGroup);
        Button downloadBtn = dialog.findViewById(R.id.downloadBtn);
        Button cancelBtn = dialog.findViewById(R.id.cancelBtn);

        // Add quality options
        List<VideoExtractor.VideoStream> videoStreams = new ArrayList<VideoExtractor.VideoStream>();
        for (int i = 0; i < availableStreams.size(); i++) {
            VideoExtractor.VideoStream stream = availableStreams.get(i);
            if (stream.getType().equals("video")) {
                videoStreams.add(stream);
            }
        }

        for (int i = 0; i < videoStreams.size(); i++) {
            VideoExtractor.VideoStream stream = videoStreams.get(i);
            RadioButton rb = new RadioButton(this);
            rb.setText(stream.getQuality() + " - " + stream.getFormat().toUpperCase());
            rb.setId(i);
            if (i == 0) rb.setChecked(true);
            qualityGroup.addView(rb);
        }

        // Add audio only option
        for (int i = 0; i < availableStreams.size(); i++) {
            VideoExtractor.VideoStream stream = availableStreams.get(i);
            if (stream.getType().equals("audio")) {
                RadioButton rb = new RadioButton(this);
                rb.setText("Audio Only - " + stream.getQuality());
                rb.setId(100 + i);
                qualityGroup.addView(rb);
                break;
            }
        }

        downloadBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int selectedQuality = qualityGroup.getCheckedRadioButtonId();
                int selectedFormat = formatGroup.getCheckedRadioButtonId();

                if (selectedQuality >= 0 && selectedQuality < videoStreams.size()) {
                    VideoExtractor.VideoStream stream = videoStreams.get(selectedQuality);
                    startDownload(stream.getUrl(), stream.getQuality(), "MP4");
                } else if (selectedQuality >= 100) {
                    int audioIndex = selectedQuality - 100;
                    for (int i = 0; i < availableStreams.size(); i++) {
                        if (availableStreams.get(i).getType().equals("audio")) {
                            startDownload(availableStreams.get(i).getUrl(), "Audio", "MP3");
                            break;
                        }
                    }
                }

                dialog.dismiss();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void startDownload(String url, String quality, String format) {
        DownloadItem item = new DownloadItem();
        item.setId(UUID.randomUUID().toString());
        item.setVideoId(videoId);
        item.setTitle(videoTitle);
        item.setThumbnailUrl(videoThumb);
        item.setQuality(quality);
        item.setFormat(format);
        item.setDownloadUrl(url);

        VidMateApp.getInstance().getDownloadManager().startDownload(item);

        Toast.makeText(this, "Download started: " + quality, Toast.LENGTH_SHORT).show();

        // Save to history
        saveToHistory();
    }

    private void saveToHistory() {
        VideoItem video = new VideoItem();
        video.setVideoId(videoId);
        video.setTitle(videoTitle);
        video.setThumbnailUrl(videoThumb);
        video.setChannelTitle(channelName);

        List<VideoItem> history = prefs.getHistory();

        // Remove if already exists
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i).getVideoId().equals(videoId)) {
                history.remove(i);
                break;
            }
        }

        history.add(0, video);

        // Keep only last 100
        while (history.size() > 100) {
            history.remove(history.size() - 1);
        }

        prefs.saveHistory(history);
    }

    private void shareVideo() {
        String shareUrl = "https://youtube.com/watch?v=" + videoId;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, videoTitle + "
" + shareUrl);
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (exoPlayer != null) {
            exoPlayer.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (exoPlayer != null) {
            exoPlayer.play();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (exoPlayer != null) {
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (exoPlayer != null && exoPlayer.isPlaying()) {
            exoPlayer.pause();
        }
        super.onBackPressed();
    }
}
