package com.vidmate.app.model;

import java.util.List;

public class SearchResponse {
    private String kind;
    private String etag;
    private String nextPageToken;
    private String prevPageToken;
    private PageInfo pageInfo;
    private List<SearchItem> items;

    public String getKind() { return kind; }
    public void setKind(String kind) { this.kind = kind; }

    public String getEtag() { return etag; }
    public void setEtag(String etag) { this.etag = etag; }

    public String getNextPageToken() { return nextPageToken; }
    public void setNextPageToken(String nextPageToken) { this.nextPageToken = nextPageToken; }

    public String getPrevPageToken() { return prevPageToken; }
    public void setPrevPageToken(String prevPageToken) { this.prevPageToken = prevPageToken; }

    public PageInfo getPageInfo() { return pageInfo; }
    public void setPageInfo(PageInfo pageInfo) { this.pageInfo = pageInfo; }

    public List<SearchItem> getItems() { return items; }
    public void setItems(List<SearchItem> items) { this.items = items; }

    public static class PageInfo {
        private int totalResults;
        private int resultsPerPage;

        public int getTotalResults() { return totalResults; }
        public void setTotalResults(int totalResults) { this.totalResults = totalResults; }

        public int getResultsPerPage() { return resultsPerPage; }
        public void setResultsPerPage(int resultsPerPage) { this.resultsPerPage = resultsPerPage; }
    }

    public static class SearchItem {
        private String kind;
        private String etag;
        private Id id;
        private Snippet snippet;

        public String getKind() { return kind; }
        public void setKind(String kind) { this.kind = kind; }

        public String getEtag() { return etag; }
        public void setEtag(String etag) { this.etag = etag; }

        public Id getId() { return id; }
        public void setId(Id id) { this.id = id; }

        public Snippet getSnippet() { return snippet; }
        public void setSnippet(Snippet snippet) { this.snippet = snippet; }
    }

    public static class Id {
        private String kind;
        private String videoId;
        private String playlistId;
        private String channelId;

        public String getKind() { return kind; }
        public void setKind(String kind) { this.kind = kind; }

        public String getVideoId() { return videoId; }
        public void setVideoId(String videoId) { this.videoId = videoId; }

        public String getPlaylistId() { return playlistId; }
        public void setPlaylistId(String playlistId) { this.playlistId = playlistId; }

        public String getChannelId() { return channelId; }
        public void setChannelId(String channelId) { this.channelId = channelId; }
    }

    public static class Snippet {
        private String publishedAt;
        private String channelId;
        private String title;
        private String description;
        private Thumbnails thumbnails;
        private String channelTitle;
        private String liveBroadcastContent;

        public String getPublishedAt() { return publishedAt; }
        public void setPublishedAt(String publishedAt) { this.publishedAt = publishedAt; }

        public String getChannelId() { return channelId; }
        public void setChannelId(String channelId) { this.channelId = channelId; }

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public Thumbnails getThumbnails() { return thumbnails; }
        public void setThumbnails(Thumbnails thumbnails) { this.thumbnails = thumbnails; }

        public String getChannelTitle() { return channelTitle; }
        public void setChannelTitle(String channelTitle) { this.channelTitle = channelTitle; }

        public String getLiveBroadcastContent() { return liveBroadcastContent; }
        public void setLiveBroadcastContent(String liveBroadcastContent) { this.liveBroadcastContent = liveBroadcastContent; }
    }

    public static class Thumbnails {
        private ThumbnailDetail defaultThumbnail;
        private ThumbnailDetail medium;
        private ThumbnailDetail high;
        private ThumbnailDetail standard;
        private ThumbnailDetail maxres;

        public ThumbnailDetail getDefaultThumbnail() { return defaultThumbnail; }
        public void setDefaultThumbnail(ThumbnailDetail defaultThumbnail) { this.defaultThumbnail = defaultThumbnail; }

        public ThumbnailDetail getMedium() { return medium; }
        public void setMedium(ThumbnailDetail medium) { this.medium = medium; }

        public ThumbnailDetail getHigh() { return high; }
        public void setHigh(ThumbnailDetail high) { this.high = high; }

        public ThumbnailDetail getStandard() { return standard; }
        public void setStandard(ThumbnailDetail standard) { this.standard = standard; }

        public ThumbnailDetail getMaxres() { return maxres; }
        public void setMaxres(ThumbnailDetail maxres) { this.maxres = maxres; }
    }

    public static class ThumbnailDetail {
        private String url;
        private int width;
        private int height;

        public String getUrl() { return url; }
        public void setUrl(String url) { this.url = url; }

        public int getWidth() { return width; }
        public void setWidth(int width) { this.width = width; }

        public int getHeight() { return height; }
        public void setHeight(int height) { this.height = height; }
    }
}
