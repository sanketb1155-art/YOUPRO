package com.vidmate.app.utils;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Utils {

    public static String formatViews(long views) {
        if (views >= 1000000000) {
            return new DecimalFormat("0.0").format(views / 1000000000.0) + "B";
        } else if (views >= 1000000) {
            return new DecimalFormat("0.0").format(views / 1000000.0) + "M";
        } else if (views >= 1000) {
            return new DecimalFormat("0.0").format(views / 1000.0) + "K";
        }
        return String.valueOf(views);
    }

    public static String formatDuration(String isoDuration) {
        if (isoDuration == null || isoDuration.isEmpty()) {
            return "0:00";
        }

        try {
            String duration = isoDuration.replace("PT", "");
            int hours = 0, minutes = 0, seconds = 0;

            if (duration.contains("H")) {
                String[] parts = duration.split("H");
                hours = Integer.parseInt(parts[0]);
                duration = parts[1];
            }
            if (duration.contains("M")) {
                String[] parts = duration.split("M");
                minutes = Integer.parseInt(parts[0]);
                duration = parts[1];
            }
            if (duration.contains("S")) {
                String[] parts = duration.split("S");
                seconds = Integer.parseInt(parts[0]);
            }

            if (hours > 0) {
                return String.format("%d:%02d:%02d", hours, minutes, seconds);
            }
            return String.format("%d:%02d", minutes, seconds);
        } catch (Exception e) {
            return "0:00";
        }
    }

    public static String formatTimeAgo(String publishedAt) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            Date date = sdf.parse(publishedAt);
            long time = date.getTime();
            long now = System.currentTimeMillis();
            long diff = now - time;

            long days = TimeUnit.MILLISECONDS.toDays(diff);
            if (days > 365) {
                return (days / 365) + " years ago";
            } else if (days > 30) {
                return (days / 30) + " months ago";
            } else if (days > 7) {
                return (days / 7) + " weeks ago";
            } else if (days > 0) {
                return days + " days ago";
            }

            long hours = TimeUnit.MILLISECONDS.toHours(diff);
            if (hours > 0) {
                return hours + " hours ago";
            }

            long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
            if (minutes > 0) {
                return minutes + " minutes ago";
            }

            return "Just now";
        } catch (Exception e) {
            return publishedAt;
        }
    }

    public static String formatFileSize(long bytes) {
        if (bytes >= 1073741824) {
            return new DecimalFormat("0.00").format(bytes / 1073741824.0) + " GB";
        } else if (bytes >= 1048576) {
            return new DecimalFormat("0.00").format(bytes / 1048576.0) + " MB";
        } else if (bytes >= 1024) {
            return new DecimalFormat("0.00").format(bytes / 1024.0) + " KB";
        }
        return bytes + " B";
    }

    public static String formatSpeed(long bytesPerSecond) {
        return formatFileSize(bytesPerSecond) + "/s";
    }
}
