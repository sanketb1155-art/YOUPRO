package com.vidmate.app.network;

import com.vidmate.app.model.SearchResponse;
import com.vidmate.app.model.VideoResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface YouTubeApiService {

    @GET("search")
    Call<SearchResponse> searchVideos(
        @Query("part") String part,
        @Query("q") String query,
        @Query("type") String type,
        @Query("maxResults") int maxResults,
        @Query("key") String apiKey,
        @Query("pageToken") String pageToken
    );

    @GET("search")
    Call<SearchResponse> searchVideosSimple(
        @Query("part") String part,
        @Query("q") String query,
        @Query("type") String type,
        @Query("maxResults") int maxResults,
        @Query("key") String apiKey
    );

    @GET("videos")
    Call<VideoResponse> getVideoDetails(
        @Query("part") String part,
        @Query("id") String videoId,
        @Query("key") String apiKey
    );

    @GET("videos")
    Call<VideoResponse> getPopularVideos(
        @Query("part") String part,
        @Query("chart") String chart,
        @Query("maxResults") int maxResults,
        @Query("key") String apiKey
    );

    @GET("search")
    Call<SearchResponse> getTrendingVideos(
        @Query("part") String part,
        @Query("q") String query,
        @Query("type") String type,
        @Query("order") String order,
        @Query("maxResults") int maxResults,
        @Query("key") String apiKey
    );

    @GET("search")
    Call<SearchResponse> getRelatedVideos(
        @Query("part") String part,
        @Query("relatedToVideoId") String videoId,
        @Query("type") String type,
        @Query("maxResults") int maxResults,
        @Query("key") String apiKey
    );
}
