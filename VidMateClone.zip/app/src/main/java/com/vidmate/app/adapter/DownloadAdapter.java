package com.vidmate.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.vidmate.app.R;
import com.vidmate.app.model.DownloadItem;
import com.vidmate.app.utils.Utils;
import java.util.ArrayList;
import java.util.List;

public class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.ViewHolder> {

    private Context context;
    private List<DownloadItem> downloads;
    private OnDownloadActionListener actionListener;

    public interface OnDownloadActionListener {
        void onPause(DownloadItem item);
        void onResume(DownloadItem item);
        void onCancel(DownloadItem item);
        void onDelete(DownloadItem item);
        void onOpen(DownloadItem item);
    }

    public DownloadAdapter(Context context) {
        this.context = context;
        this.downloads = new ArrayList<DownloadItem>();
    }

    public void setOnDownloadActionListener(OnDownloadActionListener listener) {
        this.actionListener = listener;
    }

    public void setDownloads(List<DownloadItem> downloads) {
        this.downloads = downloads;
        notifyDataSetChanged();
    }

    public void updateItem(DownloadItem item) {
        for (int i = 0; i < downloads.size(); i++) {
            if (downloads.get(i).getId().equals(item.getId())) {
                downloads.set(i, item);
                notifyItemChanged(i);
                break;
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_download, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final DownloadItem item = downloads.get(position);

        holder.titleText.setText(item.getTitle());
        holder.qualityText.setText(item.getQuality() + " • " + item.getFormat());
        holder.statusText.setText(item.getStatusText());

        // Progress
        holder.progressBar.setProgress(item.getProgress());
        holder.progressText.setText(item.getProgress() + "%");

        String sizeText = Utils.formatFileSize(item.getDownloadedSize());
        if (item.getTotalSize() > 0) {
            sizeText += " / " + Utils.formatFileSize(item.getTotalSize());
        }
        holder.sizeText.setText(sizeText);

        // Thumbnail
        Glide.with(context)
            .load(item.getThumbnailUrl())
            .placeholder(R.drawable.thumbnail_placeholder)
            .into(holder.thumbnailImage);

        // Action buttons based on status
        holder.actionButton.setVisibility(View.VISIBLE);
        holder.deleteButton.setVisibility(View.VISIBLE);

        switch (item.getStatus()) {
            case DownloadItem.STATUS_DOWNLOADING:
                holder.actionButton.setImageResource(android.R.drawable.ic_media_pause);
                holder.actionButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (actionListener != null) actionListener.onPause(item);
                    }
                });
                break;

            case DownloadItem.STATUS_PAUSED:
            case DownloadItem.STATUS_PENDING:
                holder.actionButton.setImageResource(android.R.drawable.ic_media_play);
                holder.actionButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (actionListener != null) actionListener.onResume(item);
                    }
                });
                break;

            case DownloadItem.STATUS_COMPLETED:
                holder.actionButton.setImageResource(android.R.drawable.ic_menu_view);
                holder.actionButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (actionListener != null) actionListener.onOpen(item);
                    }
                });
                break;

            case DownloadItem.STATUS_FAILED:
                holder.actionButton.setImageResource(android.R.drawable.ic_menu_rotate);
                holder.actionButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (actionListener != null) actionListener.onResume(item);
                    }
                });
                break;
        }

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (actionListener != null) actionListener.onDelete(item);
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (item.getStatus() == DownloadItem.STATUS_COMPLETED && actionListener != null) {
                    actionListener.onOpen(item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return downloads.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnailImage;
        TextView titleText;
        TextView qualityText;
        TextView statusText;
        TextView sizeText;
        TextView progressText;
        ProgressBar progressBar;
        ImageButton actionButton;
        ImageButton deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            thumbnailImage = itemView.findViewById(R.id.thumbnailImage);
            titleText = itemView.findViewById(R.id.titleText);
            qualityText = itemView.findViewById(R.id.qualityText);
            statusText = itemView.findViewById(R.id.statusText);
            sizeText = itemView.findViewById(R.id.sizeText);
            progressText = itemView.findViewById(R.id.progressText);
            progressBar = itemView.findViewById(R.id.progressBar);
            actionButton = itemView.findViewById(R.id.actionButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
